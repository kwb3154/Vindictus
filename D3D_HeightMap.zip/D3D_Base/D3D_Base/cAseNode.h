#pragma once
#include "cMtlTex.h"

class cAseNode : public cObject
{
private:
	int								m_nTriCnt;
	LPDIRECT3DVERTEXBUFFER9			m_pVB;
	std::vector<cAseNode*>			m_vecChild;

	SYNTHESIZE_REF(std::vector<ST_PNT_VERTEX>, m_vecVertex, Vertex);
	SYNTHESIZE_ADD_REF( cMtlTex*, m_pMtlTex, MtlTex );
	SYNTHESIZE_REF( D3DXMATRIXA16, m_matWorldTM, WorldTM );
	SYNTHESIZE_REF( D3DXMATRIXA16, m_matLocalTM, LocalTM );
	SYNTHESIZE_REF( std::vector<ST_POS_SAMPLE>, m_vecPosTrack, PosTrack );
	SYNTHESIZE_REF( std::vector<ST_ROT_SAMPLE>, m_vecRotTrack, RotTrack );

public:
	cAseNode();
	~cAseNode();

	void Update(int nKeyFrame, D3DXMATRIXA16* pMatParent);
	void Render();
	void AddChild( cAseNode* pChild );
	void Destroy();

	void CalcOriginLocalTM( D3DXMATRIXA16* pMatParent );
	void CalcLocalRotation( IN int nKeyFrame, OUT D3DXMATRIXA16& matR );
	void CalcLocalTrnaslation( IN int nKeyFrame, OUT D3DXMATRIXA16& matT );
	int	GetKeyFrame();

	DWORD m_dwFirstFrame;
	DWORD m_dwLastFrame;
	DWORD m_dwFrameSpeed;
	DWORD m_dwTicksPerFrame;

	void BuildVB( std::vector<ST_PNT_VERTEX>& vecVertex );

};

