#pragma once

class cAction;
class iMap;

class cCharacter : public cGameObject
{
protected:
	float			m_fRotY;
	D3DXMATRIXA16	m_matWorldTM;
	iMap*			m_pMap;

	SYNTHESIZE(cAction*, m_pAction, Action);


public:
	cCharacter();
	virtual ~cCharacter();


	virtual void Setup();
	virtual void Update(iMap* pMap);
	virtual void Render();

	virtual void WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	virtual void OnActionFinish(cAction* pSender) override;
};

