#include "stdafx.h"
#include "cAction.h"


cAction::cAction()
{
}


cAction::~cAction()
{
}
