#pragma once
class cRay
{
private:
	D3DXVECTOR3		m_vPos;
	D3DXVECTOR3		m_vDir;

public:
	cRay();
	~cRay();

	static cRay RayAtViewSpace( int nSceenX, int nScreenY );
	static cRay RayAtWorldSpace( int nSceenX, int nScreenY );

	bool	IsPicked( ST_SPHERE* pSphere );
	bool	IntersectTri( IN D3DXVECTOR3& v0, IN D3DXVECTOR3& v1, IN D3DXVECTOR3& v2,
		OUT D3DXVECTOR3& vPickedPosition );
};

