#include "stdafx.h"
#include "cCubeMan.h"

#include "cCubeBody.h"
#include "cCubeHead.h"
#include "cCubeLArm.h"
#include "cCubeRArm.h"
#include "cCubeLLeg.h"
#include "cCubeRLeg.h"
#include "cAction.h"


cCubeMan::cCubeMan()
	: m_pRoot(NULL)
	, m_pTexture(NULL)
{
}


cCubeMan::~cCubeMan()
{
	if (m_pRoot)
	{
		m_pRoot->Destroy();
	}

	SAFE_RELEASE(m_pTexture);
}

void cCubeMan::Setup()
{
	if (FAILED(D3DXCreateTextureFromFile(g_pD3DDevice,
		L"batman.png", &m_pTexture)))
	{
		assert(false && "�ؽ�ó �ε� ����!");
	}

	ZeroMemory(&m_stMtl, sizeof(D3DMATERIAL9));
	m_stMtl.Ambient = D3DXCOLOR(0.7f, 0.7f, 0.7f, 1.0f);
	m_stMtl.Diffuse = D3DXCOLOR(0.7f, 0.7f, 0.7f, 1.0f);
	m_stMtl.Specular = D3DXCOLOR(0.7f, 0.7f, 0.7f, 1.0f);

	cCubeBody* pBody = new cCubeBody;
	pBody->Setup();
	pBody->SetParentWorldTM(&m_matWorldTM);

	m_pRoot = pBody;

	cCubeHead* pHead = new cCubeHead;
	pHead->Setup();

	m_pRoot->AddChild(pHead);

	cCubeLArm* pLArm = new cCubeLArm;
	pLArm->Setup();
	pLArm->SetRotDeltaX(-0.1f);

	m_pRoot->AddChild(pLArm);

	cCubeRArm* pRArm = new cCubeRArm;
	pRArm->Setup();
	pRArm->SetRotDeltaX(0.1f);

	m_pRoot->AddChild(pRArm);

	cCubeLLeg* pLLeg = new cCubeLLeg;
	pLLeg->Setup();
	pLLeg->SetRotDeltaX(0.1f);

	m_pRoot->AddChild(pLLeg);

	cCubeRLeg* pRLeg = new cCubeRLeg;
	pRLeg->Setup();
	pRLeg->SetRotDeltaX(-0.1f);

	m_pRoot->AddChild(pRLeg);
}

void cCubeMan::Update( iMap* pMap )
{
	cCharacter::Update(pMap);

	if (m_pRoot)
	{
		m_pRoot->Update();
	}
}

void cCubeMan::Render()
{
	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, true);
	g_pD3DDevice->SetMaterial(&m_stMtl);

	g_pD3DDevice->SetTransform(D3DTS_WORLD, &m_matWorldTM);
	g_pD3DDevice->SetTexture(0, m_pTexture);

	if (m_pRoot)
	{
		m_pRoot->Render();
	}
}
