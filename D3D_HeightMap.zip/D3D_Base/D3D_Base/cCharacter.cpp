#include "stdafx.h"
#include "cCharacter.h"
#include "iMap.h"


cCharacter::cCharacter()
	: m_pAction(NULL)
	, m_fRotY(0.0f)
	, m_pMap(NULL)
{
}


cCharacter::~cCharacter()
{
	SAFE_RELEASE(m_pAction);
}

void cCharacter::Setup()
{
}

void cCharacter::Update( iMap* pMap )
{
	m_pMap = pMap;

	if ( GetKeyState( 'A' ) & 0x8000 )
	{
		m_fRotY -= 0.1f;
	}
	if ( GetKeyState( 'D' ) & 0x8000 )
	{
		m_fRotY += 0.1f;
	}

	D3DXVECTOR3 vPosition = m_vPosition;
	if ( GetKeyState( 'W' ) & 0x8000 )
	{
		vPosition = m_vPosition + ( m_vDirection * 0.1f );
	}
	if ( GetKeyState( 'S' ) & 0x8000 )
	{
		vPosition = m_vPosition - ( m_vDirection * 0.1f );
	}

	D3DXMATRIXA16 matR, matT;
	D3DXMatrixRotationY( &matR, m_fRotY );
	m_vDirection = D3DXVECTOR3( 0, 0, 1 );
	D3DXVec3TransformNormal( &m_vDirection, &m_vDirection, &matR );

	//D3DXMATRIXA16 matR, matT;
	//D3DXVec3Normalize(&m_vDirection, &m_vDirection);
	//D3DXVECTOR3	vUp(0, 1, 0);
	//D3DXVECTOR3 vRight;
	//D3DXVec3Cross(&vRight, &vUp, &m_vDirection);
	//D3DXVec3Normalize(&vRight, &vRight);
	//D3DXVec3Cross(&vUp, &m_vDirection, &vRight);
	//D3DXVec3Normalize(&vUp, &vUp);
	//D3DXMatrixLookAtLH(&matR, &D3DXVECTOR3(0, 0, 0), &m_vDirection, &vUp);
	//D3DXMatrixTranspose(&matR, &matR);

	//if (m_pAction)
	//{
	//	m_pAction->Update();
	//}

	if ( m_pMap )
	{
		if ( m_pMap->GetHeight( vPosition.x, vPosition.y, vPosition.z ))
		{
			m_vPosition = vPosition;
		}
	}
	else
	{
		m_vPosition = vPosition;
	}

	D3DXMatrixTranslation(&matT, m_vPosition.x, m_vPosition.y + 1.0f, m_vPosition.z);
	m_matWorldTM = matR * matT;
}

void cCharacter::Render()
{
}

void cCharacter::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
}

void cCharacter::OnActionFinish(cAction * pSender)
{
}
