#pragma once

class cCamera;
class cCube;
class cGrid;
class cCubeMan;
class cInterpolation;
class cObjLoader;
class cGroup;
class iMap;
class cAseLoader;
class cAseNode;
class cMtlTex;

class cMainGame
{
private:
	cCamera*	m_pCamera;
	cCube*		m_pCube;
	cGrid*		m_pGrid;
	cCubeMan*	m_pCubeMan;
	cInterpolation*	m_pInterpolation;
	cObjLoader*	m_pObjLoader;
	iMap*		m_pMap;
	cAseLoader*	m_pAseLoader;
	cAseNode*	m_pRootNode;

	std::vector<cGroup*>	m_vecGroup;

	LPDIRECT3DTEXTURE9	m_pTexture;
	std::vector<ST_PNT_VERTEX>	m_vecVertex;

	LPD3DXFONT					m_pFont;
	LPD3DXMESH					m_pObjMesh;
	std::vector<cMtlTex*>		m_vecObjMtlTex;

	// ��ü
	LPD3DXMESH					m_pMeshSphere;
	std::vector<ST_SPHERE>		m_vecSphere;
	D3DMATERIAL9				m_mtlNone;
	D3DMATERIAL9				m_mtlPicked;

public:
	cMainGame();
	~cMainGame();

	// ��ü
	void SetupSphere();
	void RenderSphere();

	void SetLight();

	void Setup();
	void Update();
	void Render();

	void RenderObject();
	void LoadSurface();

	void RenderObjMesh();

	void WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
};

