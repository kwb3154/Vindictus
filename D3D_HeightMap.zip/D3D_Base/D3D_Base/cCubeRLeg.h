#pragma once
#include "cCubeNode.h"
class cCubeRLeg :
	public cCubeNode
{
public:
	cCubeRLeg();
	~cCubeRLeg();

	virtual void Setup() override;
};

