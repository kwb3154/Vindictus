#include "stdafx.h"
#include "cCube.h"
#


cCube::cCube()
	: m_fRotY(0.0f)
	, m_vPosition(0, 0, 0)
	, m_vDirection(0, 0, 1)
{
	D3DXMatrixIdentity(&m_matWorld);
}


cCube::~cCube()
{
}

void cCube::Setup()
{
	ST_PC_VERTEX v;
	v.c = D3DCOLOR_XRGB(rand() % 256, rand() % 256, rand() % 256);

	v.p = D3DXVECTOR3(-1.0f, -1.0f, 0.0f);
	m_vecVertex.push_back(v);

	v.p = D3DXVECTOR3(-1.0f, 1.0f, 0.0f);
	m_vecVertex.push_back(v);

	v.p = D3DXVECTOR3(1.0f, 1.0f, 0.0f);
	m_vecVertex.push_back(v);
}

void cCube::Update()
{
	D3DXMATRIXA16 matR, matT;
	D3DXMatrixRotationY(&matR, m_fRotY);
	m_vDirection = D3DXVECTOR3(0, 0, 1);
	D3DXVec3TransformNormal(&m_vDirection, &m_vDirection, &matR);
	D3DXMatrixTranslation(&matT, m_vPosition.x, m_vPosition.y, m_vPosition.z);
	m_matWorld = matR * matT;
}

void cCube::Render()
{
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &m_matWorld);
	g_pD3DDevice->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);
	g_pD3DDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST,
		m_vecVertex.size() / 3,
		&m_vecVertex[0],
		sizeof(ST_PC_VERTEX));
}
