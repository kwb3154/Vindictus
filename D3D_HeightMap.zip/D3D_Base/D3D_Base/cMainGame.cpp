#include "stdafx.h"
#include "cMainGame.h"
#include "cDeviceManager.h"

#include "cCamera.h"
#include "cCube.h"
#include "cGrid.h"
#include "cCubeMan.h"
#include "cInterpolation.h"
#include "cObjLoader.h"
#include "cGroup.h"
#include "cObjMap.h"
#include "cAseLoader.h"
#include "cAseNode.h"
#include "cRay.h"
#include "cHeightMap.h"

cMainGame::cMainGame()
	: m_pCamera(NULL)
	, m_pCube(NULL)
	, m_pGrid(NULL)
	, m_pCubeMan(NULL)
	, m_pTexture(NULL)
	, m_pInterpolation(NULL)
	, m_pObjLoader(NULL)
	, m_pMap(NULL)
	, m_pAseLoader(NULL)
	, m_pRootNode(NULL)
	, m_pFont(NULL)
	, m_pObjMesh(NULL)
	, m_pMeshSphere(NULL)
{
}


cMainGame::~cMainGame()
{
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pCube);
	SAFE_DELETE(m_pGrid);
	SAFE_DELETE(m_pCubeMan);
	SAFE_RELEASE(m_pTexture);
	SAFE_DELETE(m_pInterpolation);
	SAFE_DELETE(m_pObjLoader);
	SAFE_DELETE( m_pMap );
	SAFE_DELETE( m_pAseLoader );
	SAFE_RELEASE( m_pObjMesh );
	SAFE_RELEASE( m_pMeshSphere );

	for each ( auto p in m_vecObjMtlTex )
	{
		SAFE_RELEASE( p );
	}

	for each ( auto p in m_vecGroup )
	{
		SAFE_RELEASE( p );
	}
	m_vecGroup.clear();
	m_pRootNode->Destroy();

	g_pObjectManager->Destroy();
	g_pTextureManager->Destroy();
	g_pDeviceManager->Destroy();
	g_pFontManager->Destroy();
}

void cMainGame::SetupSphere()
{
	D3DXCreateSphere( g_pD3DDevice, 2.0f, 20, 20, &m_pMeshSphere, NULL );

	for ( int i = 0; i < 4; i++ )
	{
		ST_SPHERE	s;
		s.fRadius = 2.0f;
		s.vCenter = D3DXVECTOR3( 0, 0, -5 + 5 * i );
		m_vecSphere.push_back( s );
	}

	ZeroMemory( &m_mtlNone, sizeof( D3DMATERIAL9 ) );
	m_mtlNone.Ambient = D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f );
	m_mtlNone.Diffuse = D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f );
	m_mtlNone.Specular = D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f );

	ZeroMemory( &m_mtlPicked, sizeof( D3DMATERIAL9 ) );
	m_mtlPicked.Ambient = D3DXCOLOR( 1.0f, 0.0f, 0.0f, 1.0f );
	m_mtlPicked.Diffuse = D3DXCOLOR( 1.0f, 0.0f, 0.0f, 1.0f );
	m_mtlPicked.Specular = D3DXCOLOR( 1.0f, 0.0f, 0.0f, 1.0f );
}

void cMainGame::RenderSphere()
{
	D3DXMATRIXA16	matWorld;
	for ( size_t i = 0; i < m_vecSphere.size(); i++ )
	{
		D3DXMatrixIdentity( &matWorld );
		matWorld._41 = m_vecSphere[i].vCenter.x;
		matWorld._42 = m_vecSphere[i].vCenter.y;
		matWorld._43 = m_vecSphere[i].vCenter.z;
		g_pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );
		g_pD3DDevice->SetMaterial( m_vecSphere[i].isPicked ? &m_mtlPicked :
			&m_mtlNone );
		g_pD3DDevice->SetTexture( 0, NULL );

		m_pMeshSphere->DrawSubset( 0 );
	}
}

void cMainGame::SetLight()
{
	D3DLIGHT9 light;

	ZeroMemory(&light, sizeof(D3DLIGHT9));
	light.Type = D3DLIGHT_SPOT;
	//light.Ambient = D3DXCOLOR()
	light.Diffuse = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	light.Specular = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	light.Position = D3DXVECTOR3(5.0f, 5.0f, 0.0f);
	light.Falloff = 1.0f;
	light.Range = 1000.0f;
	light.Theta = D3DX_PI / 30.0f;
	light.Phi = D3DX_PI / 60.0f;
	light.Attenuation0 = 1.0f;

	D3DXVECTOR3 vDir(1.0f, 1.0f, 0.0f);
	D3DXVec3Normalize(&vDir, &vDir);
	light.Direction = vDir;
	g_pD3DDevice->SetLight(0, &light);
	g_pD3DDevice->LightEnable(0, true);


	D3DLIGHT9 stLight;
	ZeroMemory(&stLight, sizeof(D3DLIGHT9));
	stLight.Type = D3DLIGHT_DIRECTIONAL;
	stLight.Ambient = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	stLight.Diffuse = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	stLight.Specular = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	vDir = D3DXVECTOR3(1.0f, -1.0f, 1.0f);
	D3DXVec3Normalize(&vDir, &vDir);
	stLight.Direction = vDir;
	g_pD3DDevice->SetLight(0, &stLight);
	g_pD3DDevice->LightEnable(0, true);

	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, true);

}

void cMainGame::Setup()
{
	m_pCamera = new cCamera;
	m_pCamera->Setup();

	m_pCube = new cCube;
	m_pCube->Setup();

	m_pGrid = new cGrid;
	m_pGrid->Setup();

	m_pCubeMan = new cCubeMan;
	m_pCubeMan->Setup();

	m_pInterpolation = new cInterpolation;
	m_pInterpolation->Setup();

	m_pObjLoader = new cObjLoader;
	m_pObjLoader->Load( m_vecGroup, "obj", "map.obj");

	m_pAseLoader = new cAseLoader;
	m_pRootNode = m_pAseLoader->Load( "woman/woman_01_all.ase" );

	LoadSurface();

	m_pObjMesh = m_pObjLoader->LoadMesh( m_vecObjMtlTex, "obj", "map.obj" );

	// height map
	cHeightMap*	pMap = new cHeightMap;
	pMap->Setup( "HeightMapData/", "HeightMap.raw", "terrain.jpg" );
	m_pMap = pMap;


	// triangle
	if (FAILED(D3DXCreateTextureFromFile(g_pD3DDevice, 
		L"batman.png", &m_pTexture)))
	{
		assert(false && "�ؽ�ó �ε� ����!");
	}
/*
	ST_PNT_VERTEX v;
	v.p = D3DXVECTOR3(0, 0, 0);
	v.n = D3DXVECTOR3(0, 0, 1);
	v.t = D3DXVECTOR2(0, 1);
	m_vecVertex.push_back(v);

	v.p = D3DXVECTOR3(0, 1, 0);
	v.n = D3DXVECTOR3(0, 0, 1);
	v.t = D3DXVECTOR2(0, 0.5f);
	m_vecVertex.push_back(v);

	v.p = D3DXVECTOR3(1, 0, 0);
	v.n = D3DXVECTOR3(0, 0, 1);
	v.t = D3DXVECTOR2(1, 1);
	m_vecVertex.push_back(v);*/

	SetLight();
	SetupSphere();
}

void cMainGame::Update()
{
	g_pTimeManager->Update();

	if (m_pCamera)
		m_pCamera->Update();

	//if (m_pCubeMan)
	//	m_pCubeMan->Update(m_pMap);

	//if ( m_pRootNode )
	//{
	//	m_pRootNode->Update(m_pRootNode->GetKeyFrame(), NULL );
	//}


	//if (m_pInterpolation)
	//	m_pInterpolation->Update();
}

void cMainGame::Render()
{
	g_pD3DDevice->Clear(NULL,
		NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_XRGB(47, 121, 122),
		1.0f, 0);

	g_pD3DDevice->BeginScene();

	if (m_pGrid)
		m_pGrid->Render();

	if ( m_pMap )
	{
		m_pMap->Render();
	}


	//if (m_pCubeMan)
	//	m_pCubeMan->Render();

	if ( m_pRootNode )
		m_pRootNode->Render();


	g_pD3DDevice->EndScene();

	g_pD3DDevice->Present(NULL, NULL, NULL, NULL);
}

void cMainGame::RenderObject()
{
	D3DXMATRIXA16 matWorld, matS, matR;
	D3DXMatrixIdentity( &matWorld );
	D3DXMatrixScaling( &matS, 0.02f, 0.02f, 0.02f );
	D3DXMatrixRotationX( &matR, -D3DX_PI / 2.0f );
	matWorld = matS * matR;
	g_pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	for each ( auto p in m_vecGroup )
	{
		p->Render();
	}
}

void cMainGame::LoadSurface()
{
	D3DXMATRIXA16 matWorld, matS, matR;
	D3DXMatrixIdentity( &matWorld );
	D3DXMatrixScaling( &matS, 0.02f, 0.02f, 0.02f );
	D3DXMatrixRotationX( &matR, -D3DX_PI / 2.0f );
	matWorld = matS * matR;

	m_pMap = new cObjMap( "obj", "map_surface.obj", &matWorld );
}

void cMainGame::RenderObjMesh()
{
	D3DXMATRIXA16	matWorld, matR, matS;
	D3DXMatrixIdentity( &matWorld );
	D3DXMatrixScaling( &matS, 0.02f, 0.02f, 0.02f );
	D3DXMatrixRotationX( &matR, -D3DX_PI / 2.0f );
	matWorld = matS * matR;

	g_pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	for ( size_t i = 0; i < m_vecObjMtlTex.size(); i++ )
	{
		g_pD3DDevice->SetMaterial( &m_vecObjMtlTex[i]->GetMaterial() );
		g_pD3DDevice->SetTexture( 0, m_vecObjMtlTex[i]->GetTexture() );
		m_pObjMesh->DrawSubset( i );
	}
}

void cMainGame::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (m_pCamera)
	{
		m_pCamera->WndProc(hWnd, message, wParam, lParam);
	}

	switch ( message )
	{
	case WM_LBUTTONDOWN:
		{
			cRay r = cRay::RayAtWorldSpace( LOWORD( lParam ), HIWORD( lParam ) );
			for ( size_t i = 0; i < m_vecSphere.size(); i++ )
			{
				m_vecSphere[i].isPicked = r.IsPicked( &m_vecSphere[i] );
			}
		}
		break;
	}
}
