#pragma once
#include "cCubeNode.h"
class cCubeRArm :
	public cCubeNode
{
public:
	cCubeRArm();
	~cCubeRArm();

	virtual void Setup() override;
};

