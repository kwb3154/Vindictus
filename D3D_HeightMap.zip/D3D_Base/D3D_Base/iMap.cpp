#include "stdafx.h"
#include "iMap.h"


iMap::iMap()
{
}


iMap::~iMap()
{
}
