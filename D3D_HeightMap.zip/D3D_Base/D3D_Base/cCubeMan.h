#pragma once

#include "cCharacter.h"

class cCubeNode;
class iMap;

class cCubeMan : public cCharacter
{
protected:
	cCubeNode*			m_pRoot;
	D3DMATERIAL9		m_stMtl;
	LPDIRECT3DTEXTURE9	m_pTexture;

public:
	cCubeMan();
	~cCubeMan();

	void Setup();
	void Update(iMap* pMap);
	void Render();
};

